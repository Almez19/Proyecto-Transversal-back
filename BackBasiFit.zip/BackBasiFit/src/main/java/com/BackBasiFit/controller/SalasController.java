package com.BackBasiFit.controller;

import java.net.URI;
import java.time.LocalDate;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.BackBasiFit.entity.Clases;
import com.BackBasiFit.entity.Salas;
import com.BackBasiFit.service.ClasesService;
import com.BackBasiFit.service.SalasService;

@RestController
@RequestMapping("/api/salas")
public class SalasController {

    private final SalasService salasService;
    private final ClasesService clasesService;

    public SalasController(SalasService salasService, ClasesService clasesService) {
        this.salasService = salasService;
        this.clasesService = clasesService;
    }

    // extra: /api/salas?gimnasioId=...
    @GetMapping
    public List<Salas> getAll(@RequestParam(required = false) String gimnasioId) {
        if (gimnasioId != null) {
            return salasService.findByGimnasio(gimnasioId);
        }
        return salasService.findAll();
    }

    @GetMapping("/{id}")
    public Salas getById(@PathVariable String id) { return salasService.findById(id); }

    @PostMapping
    public ResponseEntity<Salas> create(@RequestBody Salas s) {
        Salas saved = salasService.save(s);
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
                .buildAndExpand(saved.getId()).toUri();
        return ResponseEntity.created(location).body(saved);
    }

    @PutMapping("/{id}")
    public Salas update(@PathVariable String id, @RequestBody Salas s) {
        salasService.findById(id);
        s.setId(id);
        return salasService.save(s);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable String id) {
        salasService.delete(id);
        return ResponseEntity.noContent().build();
    }

    // EXTRA: clases de una sala, opcionalmente filtradas por fecha
    @GetMapping("/{id}/clases")
    public List<Clases> clasesDeSala(@PathVariable String id,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fecha) {
        if (fecha != null) return clasesService.findBySalaAndFecha(id, fecha);
        return clasesService.findBySala(id);
    }
}
