package com.BackBasiFit.controller;

import java.net.URI;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.BackBasiFit.entity.Membresias;
import com.BackBasiFit.service.MembresiasService;

@RestController
@RequestMapping("/api/membresias")
public class MembresiasController {

    private final MembresiasService membresiasService;

    public MembresiasController(MembresiasService membresiasService) {
        this.membresiasService = membresiasService;
    }

    // extra: /api/membresias?clienteId=...&activa=true
    @GetMapping
    public Object getAll(@RequestParam(required = false) String clienteId,
                         @RequestParam(required = false) Boolean activa) {
        if (clienteId != null && Boolean.TRUE.equals(activa)) {
            return membresiasService.findActivaByCliente(clienteId);
        }
        if (clienteId != null) {
            return membresiasService.findByCliente(clienteId);
        }
        return membresiasService.findAll();
    }

    @GetMapping("/{id}")
    public Membresias getById(@PathVariable String id) { return membresiasService.findById(id); }

    @PostMapping
    public ResponseEntity<Membresias> create(@RequestBody Membresias m) {
        Membresias saved = membresiasService.save(m);
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
                .buildAndExpand(saved.getId()).toUri();
        return ResponseEntity.created(location).body(saved);
    }

    @PutMapping("/{id}")
    public Membresias update(@PathVariable String id, @RequestBody Membresias m) {
        membresiasService.findById(id);
        m.setId(id);
        return membresiasService.save(m);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable String id) {
        membresiasService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
