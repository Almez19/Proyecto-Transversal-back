package com.BackBasiFit.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import org.springframework.stereotype.Service;
import com.BackBasiFit.entity.Membresias;
import com.BackBasiFit.repository.MembresiasRepository;

@Service
public class MembresiasService {
    private final MembresiasRepository repo;

    public MembresiasService(MembresiasRepository repo) { 
        this.repo = repo; 
    }

    public List<Membresias> findAll() { 
        return repo.findAll(); 
    }

    public Membresias findById(String id) {
        return repo.findById(id).orElseThrow(() -> new IllegalArgumentException("No se encuentra esta membresia"));
    }

    public List<Membresias> findByCliente(String clienteId) { 
        return repo.findByClienteId(clienteId); 
    }

    public Membresias findActivaByCliente(String clienteId) {
        return repo.findFirstByClienteIdAndEstadoTrueOrderByFechaFinalDesc(clienteId).orElseThrow(() -> new IllegalArgumentException("No hay ninguna membresia activada"));
    }

    public Membresias save(Membresias m) {
        DateTimeFormatter fmt = DateTimeFormatter.ISO_LOCAL_DATE; 
        if (m.getFechaInicio() != null && m.getFechaFinal() != null) {
            LocalDate ini = LocalDate.parse(m.getFechaInicio(), fmt);
            LocalDate fin = LocalDate.parse(m.getFechaFinal(), fmt);

            if (!ini.isBefore(fin)) {
                throw new IllegalArgumentException("fecha_inicio debe ser menor que fecha_final");
            }
        }

        if (m.getFechaInicio() == null) {
            m.setFechaInicio(LocalDate.now().format(fmt));
        }

        return repo.save(m);
    }

    public void delete(String id) { 
        repo.deleteById(id); 
    }
}
